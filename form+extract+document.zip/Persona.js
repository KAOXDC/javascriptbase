export default class Persona {
    constructor(nombre, apellido, fechaNacimiento, email, telefono) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.fechaNacimiento = fechaNacimiento;
        this.email = email;
        this.telefono = telefono;
    }
}
