// const lista = [1,2,3,4]
// module.exports = { lista }


// export con html
export const lista = [1,2,3,4]


